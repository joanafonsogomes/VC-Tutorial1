imagem = imread('lena.png');
kernel = 5;
sigma = 3;


canny = main_CannyDetector(imagem,kernel,sigma,20,40);