# VC_Tutorial1
Tutorial 1: Image Filtering and Edge Detection


[OVERLEAF](https://www.overleaf.com/3165716239fnrmjmxknsjq)
